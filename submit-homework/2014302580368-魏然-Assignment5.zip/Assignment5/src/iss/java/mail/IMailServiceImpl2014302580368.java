package iss.java.mail;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * Created by weiran on 2015/11/19
 * 
 */
public class IMailServiceImpl2014302580368 implements IMailService{
	
	/**
     * 发送邮件的props文件
     */
    private final transient Properties prop = System.getProperties();
    private final transient Properties prop1 = System.getProperties();
    /**
     * 邮件服务器登录验证
     */
    private transient MailAuthenticator authenticator;

    /**
     * 邮箱session
     */
    private transient Session session;
    private transient Session session1;

    
	
    /**
     * 初始化并连接所有的邮件服务器
     * @throws MessagingException 初始化或连接异常
     */
    @Override
	public void connect() throws MessagingException {
		prop.setProperty("mail.host", "smtp.qq.com");
	    prop.setProperty("mail.transport.protocol", "smtp");
		prop.setProperty("mail.smtp.auth", "true");
		
		prop1.put("mail.store.protocol", "imap");
        prop1.put("mail.imap.host", "imap.qq.com");
        prop1.setProperty("mail.imap.auth", "true");
        prop1.setProperty("mail.imap.ssl.enable","true");
        
        
		//验证
        authenticator = new MailAuthenticator("2454304860@qq.com","199744.Gyy");
		//创建Session
        session = Session.getInstance(prop, authenticator);   
        //创建Session1
        session1 = Session.getInstance(prop1, authenticator);
	}

	
    /**
     * 发送单封邮件
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException 发送邮件错误
     */
	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		
		//创建mime类型邮件
	    MimeMessage message = new MimeMessage(session);
	    
		//设置发信人
		message.setFrom(new InternetAddress("2454304860@qq.com"));
		
		//设置收件人
		message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
		
		//设置主题
		message.setSubject(subject);
		
		//设置邮件内容
		message.setContent(content.toString(), "text/html;charset=UTF-8");
		Transport.send(message);
		 message.setFlag(Flags.Flag.RECENT, true);
		
	}

	
	/**
     * 询问服务器是否有新邮件到达
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException 询问服务器出错
     */
	@Override
	public boolean listen() throws MessagingException {
		Store store1 = session1.getStore();
		store1.connect();
		
		//Get folder
		Folder folder = store1.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		if(folder.getUnreadMessageCount()>0)
			return true;
		else
			return false;
	}

	
	/**
     * 接收自动回复的内容，并转换为字符串
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException 查询邮件异常
     * @throws IOException 下载邮件异常
     */
	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		
       
		String content ="";
		Store store = session1.getStore();
		store.connect();
		
		//Get folder
		Folder folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		
		
		//get directory
		Message messages[]=folder.getMessages();
		for(int i=0;i<messages.length;i++){
			System.out.println("第 " + (i+1) + "封邮件的主题：" + subject);
            System.out.println("第 " + (i+1) + "封邮件的发件人地址：" + sender);
            content+=("第"+(i+1)+"封的内容:"+messages[i].getContent()+"\n");
            messages[i].setFlag(Flags.Flag.SEEN, true);
            
		}
		folder.close(false);
        store.close();
		return content;
	}

}
